package com.jcraft.jsch;

final class Version {

  private static final String VERSION = "0.2.26";

  static String getVersion() {
    return VERSION;
  }
}
