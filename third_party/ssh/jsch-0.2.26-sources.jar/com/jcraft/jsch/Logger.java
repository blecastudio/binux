/*
 * Copyright (c) 2006-2018 ymnk, JCraft,Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted
 * provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions
 * and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of
 * conditions and the following disclaimer in the documentation and/or other materials provided with
 * the distribution.
 *
 * 3. The names of the authors may not be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL JCRAFT, INC. OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jcraft.jsch;

import java.io.PrintWriter;
import java.io.StringWriter;

public interface Logger {

  public final int DEBUG = 0;
  public final int INFO = 1;
  public final int WARN = 2;
  public final int ERROR = 3;
  public final int FATAL = 4;

  public boolean isEnabled(int level);

  public void log(int level, String message);

  public default void log(int level, String message, Throwable cause) {
    if (!isEnabled(level)) {
      return;
    }
    if (cause != null) {
      StringWriter sw = new StringWriter();
      try (PrintWriter pw = new PrintWriter(sw, true)) {
        cause.printStackTrace(pw);
      }
      message += System.lineSeparator() + sw.toString();
    }
    log(level, message);
  }

  /*
   * public final Logger SIMPLE_LOGGER=new Logger(){ public boolean isEnabled(int level){return
   * true;} public void log(int level, String message){System.err.println(message);} }; final Logger
   * DEVNULL=new Logger(){ public boolean isEnabled(int level){return false;} public void log(int
   * level, String message){} };
   */
}
